
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="search.js"></script>
</head>
<body>
<div align="center">
    <h4 style="color: black">Search Vehicle</h4>
</div>
<div align="center">
<form>
    <input type="text" name="search_input" id="search_input" value="">
    <span id="validate"></span>
</form>
<div style="display:none;">
<button name="search" id="search">Search</button>
</div>
</div>
&nbsp;
&nbsp;
&nbsp;
&nbsp;
<div  align="center" class="result" style="display: none">
    <table id="result" border="1px">
        <thead>
        <tr>
            <td>Vehicle Name</td>
            <td>Vehicle Number</td>
        </tr>

        </thead>
        <tbody>
        <tr>
            <td></td>
            <td></td>
        </tr>

        </tbody>
    </table>
</div>
<div class="no_result" style="display:none; ">
<h4> No Result Found !! </h4>
</div>
</body>

</html>

<?php