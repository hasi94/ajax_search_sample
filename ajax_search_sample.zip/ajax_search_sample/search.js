/**
 * Created by Hasitha on 4/17/2018.
 */
$( document ).ready(function() {
	
	$( "#search_input" ).keyup(function() {
	$( "#search" ).trigger( "click" );
});
	
    $('#search').click(function(){
        $(".result").css({display: "block"});
		  $(".no_result").css({display: "none"});
        $("#result tbody").empty();

        var searchString= $('#search_input').val();
        if(''==searchString) {
			$(".result").css({display: "none"});
        $("#result tbody").empty();
            $('#validate').replaceWith("<span id='validate'><label style='color: red'> This field is Required !</label></span>");
            return false;
        }else {
            $('#validate').replaceWith("<span id='validate'></span>");

            $.ajax({
                type: "POST",
                url: "action.php",
                data: {searchString :searchString},
                cache: false,
                dataType:"html",
                success: function(data){
                  //result
					if(data == "0 results"){
						$(".result").css({display: "none"});
						$("#result tbody").empty();
						 $(".no_result").css({display: "block"});
						//no_result
					}else{
					$("#result tbody").append(data);
					}
                   
                }
            });

        }



    });

});