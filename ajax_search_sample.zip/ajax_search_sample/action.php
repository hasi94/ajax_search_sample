<?php
/**
 * Created by PhpStorm.
 * User: Hasitha
 * Date: 4/17/2018
 * Time: 8:13 PM
 */
 $search_string=$_POST['searchString'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vehicle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT
vehicle_details.v_id,
vehicle_details.v_type,
vehicle_details.v_number
FROM
vehicle_details
WHERE
vehicle_details.v_number LIKE '$search_string%'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
          $vehicle_details [] =array(
            'vehicle_id' => $row['v_id'],
            'vehicle_type' => $row['v_type'],
            'vehicle_number' => $row['v_number'],

          );
    }
   $html ='';
    foreach ($vehicle_details as $vehicle){

        $vehicle_type=$vehicle['vehicle_type'];
        $vehicle_number=$vehicle['vehicle_number'];
$html .=" <tr>
            <td>$vehicle_type</td>
            <td>$vehicle_number</td>
        </tr>";

    }

echo $html;
} else {
    echo "0 results";
}
$conn->close();