/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 100130
Source Host           : localhost:3306
Source Database       : vehicle

Target Server Type    : MYSQL
Target Server Version : 100130
File Encoding         : 65001

Date: 2018-06-08 22:26:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for vehicle_details
-- ----------------------------
DROP TABLE IF EXISTS `vehicle_details`;
CREATE TABLE `vehicle_details` (
  `v_id` int(11) NOT NULL AUTO_INCREMENT,
  `v_type` varchar(255) DEFAULT NULL,
  `v_number` varchar(255) NOT NULL,
  PRIMARY KEY (`v_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of vehicle_details
-- ----------------------------
INSERT INTO `vehicle_details` VALUES ('1', 'car', 'BAN-5443');
INSERT INTO `vehicle_details` VALUES ('2', 'bike', 'BAA-5432');
INSERT INTO `vehicle_details` VALUES ('3', 'van', 'DDA-4321');
INSERT INTO `vehicle_details` VALUES ('4', 'jeep', 'KC-3211');
INSERT INTO `vehicle_details` VALUES ('5', 'bus', 'NC-4444');
